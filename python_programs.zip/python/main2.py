mylist=[12,52,36,39]
mylist[3]="Apple"
print(mylist)
mylist[1:3]=["hello","hai"]
print(mylist)
mylist=[12,15,25,16,19,21]
for n in mylist:
    print(n)
    
