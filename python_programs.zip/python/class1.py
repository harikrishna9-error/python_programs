class Coder:
    def __init__(self):
        self.name = "Pavan"
        self.language = "Python"

    def introduce(self):
        print(f"Yo! I'm {self.name}, and I code in {self.language}.")

# Create object without passing arguments
coder = Coder()
coder.introduce()
