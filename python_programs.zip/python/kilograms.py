kg = float(input("Enter weight in kilograms: "))
pounds = kg * 2.2
print(f"{kg} kilograms is equal to {pounds} pounds.")
