for num in range(8,90,3):
    print(num,end='')
    print()
