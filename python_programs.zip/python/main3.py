mylist=[12,15,25,16,19,21]
for n in mylist:
    print(n)
    print(19 in mylist)
    print(19 not in mylist) 
mytuple=[12,15,25,16,19,21]
for n in mytuple:
    print(n)
    print(19 in mytuple)
    print(19 not in mytuple)
