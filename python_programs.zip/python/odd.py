def even_odd(num):
    if num % 2 == 0:
        print(num, "is Even number")
    else:
        print(num, "is Odd number")

even_odd(10)
even_odd(15)
