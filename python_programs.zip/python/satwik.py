mylist=[12,32,43,56]
print(max(mylist))
mylist=[12,11,32,34]
print(mylist[2:])
mylist=[12,28,13,16,19,15]
print(mylist[-4:-1])
mylist=[12,28,13,16,19,15]
print(mylist[ :-1])
print(mylist[-4:])
