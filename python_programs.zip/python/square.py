def squarelt(number):
    print("The Square of", number, "is", number * number)

squarelt(4)
squarelt(5)
