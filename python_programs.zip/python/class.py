class student:
    def __init__(self,rollno,name,marks):
     self.rollno=rollno
     self.name=name
     self.marks=marks

student1=student(1,"rahul",50)
student2=student(2,"ravi",30)
print(student1.rollno)
print(student2.marks)
