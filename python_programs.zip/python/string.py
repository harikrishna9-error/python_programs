input_string="Hello,world!"
char_array=list(input_string)
print("Array of characters:",char_array)
