val=int(input("Enter the weight intokilograms"))
result=val*2.2 
print(f"{val}kgs in pounds is {result}pounds") 
