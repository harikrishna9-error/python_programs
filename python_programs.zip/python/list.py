numbers = [12, 45, 2, 98, 23, 67, 89]
largest = max(numbers)
print("The largest number in the list is:", largest)
