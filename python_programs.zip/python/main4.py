mytuple=[12,15,25,16,19,21]
for n in mytuple:
    print(n)
    print(19 in mytuple)
    print(19 not in mytuple)
mytuple=(12,"Apple" ,True,19.5)
for n in mytuple:
    print(n)
    print(19 in mytuple)
    print(19 not in mytuple)

